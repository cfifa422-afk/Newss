package com.cfifa.ssbubble

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/**
 * Small draggable floating button.
 * Tap = capture screen and open the editor. Long-press = cycle size. Drag = move (snaps to edge).
 */
class BubbleService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: FrameLayout? = null
    private val sizesDp = intArrayOf(30, 42, 56)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun sizePx() = dp(sizesDp[prefs.getInt("size", 0).coerceIn(0, sizesDp.size - 1)])

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("bubble", MODE_PRIVATE)
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        removeBubble()
        super.onDestroy()
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        bubble = null
    }

    private fun showBubble() {
        removeBubble()
        val px = sizePx()
        val root = FrameLayout(this)
        root.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#19C39B"))
        }
        root.alpha = 0.9f
        val dot = View(this)
        dot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
        }
        root.addView(dot, FrameLayout.LayoutParams(px / 2, px / 2, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            px, px,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("x", 0)
        lp.y = prefs.getInt("y", dp(300))

        var startX = 0f
        var startY = 0f
        var origX = 0
        var origY = 0
        var dragging = false
        var longFired = false
        val longPress = Runnable {
            longFired = true
            prefs.edit().putInt("size", (prefs.getInt("size", 0) + 1) % sizesDp.size).apply()
            showBubble()
        }

        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY
                    origX = lp.x; origY = lp.y
                    dragging = false; longFired = false
                    handler.postDelayed(longPress, 600)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startX
                    val dy = e.rawY - startY
                    if (!dragging && (abs(dx) > dp(8) || abs(dy) > dp(8))) {
                        dragging = true
                        handler.removeCallbacks(longPress)
                    }
                    if (dragging) {
                        lp.x = (origX + dx).toInt()
                        lp.y = (origY + dy).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (dragging) snapToEdge(lp, root, px)
                    else if (!longFired) capture()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    true
                }
                else -> false
            }
        }

        wm.addView(root, lp)
        bubble = root
    }

    private fun snapToEdge(lp: WindowManager.LayoutParams, view: View, px: Int) {
        val screenW = resources.displayMetrics.widthPixels
        lp.x = if (lp.x + px / 2 < screenW / 2) 0 else screenW - px
        lp.y = lp.y.coerceIn(0, resources.displayMetrics.heightPixels - px)
        wm.updateViewLayout(view, lp)
        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
    }

    private fun capture() {
        if (Build.VERSION.SDK_INT < 30) {
            Toast.makeText(this, "Screenshot needs Android 11 or newer", Toast.LENGTH_SHORT).show()
            return
        }
        bubble?.visibility = View.INVISIBLE
        handler.postDelayed({
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val hw = result.hardwareBuffer
                        val hwBmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        val bmp = hwBmp?.copy(Bitmap.Config.ARGB_8888, false)
                        hw.close()
                        bubble?.visibility = View.VISIBLE
                        if (bmp == null) {
                            Toast.makeText(this@BubbleService, "Capture failed", Toast.LENGTH_SHORT).show()
                            return
                        }
                        Thread {
                            try {
                                val f = File(cacheDir, "shot_${System.currentTimeMillis()}.png")
                                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                                handler.post { openEditor(f) }
                            } catch (_: Throwable) {
                                handler.post {
                                    Toast.makeText(this@BubbleService, "Capture failed", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }.start()
                    }

                    override fun onFailure(errorCode: Int) {
                        bubble?.visibility = View.VISIBLE
                        Toast.makeText(
                            this@BubbleService,
                            "Capture failed (code $errorCode). Wait a second and retry.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            )
        }, 150)
    }

    private fun openEditor(file: File) {
        val uri = Uri.parse("ssbubble://editor?path=" + Uri.encode(file.absolutePath))
        val intent = Intent(Intent.ACTION_VIEW, uri)
            .setPackage(packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }
}
