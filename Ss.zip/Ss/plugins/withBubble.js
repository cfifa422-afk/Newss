const fs = require('fs');
const path = require('path');
const {
  withAndroidManifest,
  withDangerousMod,
  withStringsXml,
  AndroidConfig,
} = require('expo/config-plugins');

module.exports = function withBubble(config) {
  config = withDangerousMod(config, [
    'android',
    async (cfg) => {
      const root = cfg.modRequest.platformProjectRoot;
      const pkg = cfg.android.package;
      const javaDir = path.join(root, 'app/src/main/java', ...pkg.split('.'));
      const xmlDir = path.join(root, 'app/src/main/res/xml');
      fs.mkdirSync(javaDir, { recursive: true });
      fs.mkdirSync(xmlDir, { recursive: true });
      const src = path.join(cfg.modRequest.projectRoot, 'plugins/android');
      fs.copyFileSync(path.join(src, 'BubbleService.kt'), path.join(javaDir, 'BubbleService.kt'));
      fs.copyFileSync(
        path.join(src, 'bubble_service_config.xml'),
        path.join(xmlDir, 'bubble_service_config.xml')
      );
      return cfg;
    },
  ]);

  config = withStringsXml(config, (cfg) => {
    cfg.modResults = AndroidConfig.Strings.setStringItem(
      [
        {
          $: { name: 'bubble_service_description' },
          _: 'Shows a small floating button. Tap it to capture the screen and open the editor.',
        },
      ],
      cfg.modResults
    );
    return cfg;
  });

  config = withAndroidManifest(config, (cfg) => {
    const app = cfg.modResults.manifest.application[0];
    app.service = app.service || [];
    if (!app.service.some((s) => s.$['android:name'] === '.BubbleService')) {
      app.service.push({
        $: {
          'android:name': '.BubbleService',
          'android:exported': 'true',
          'android:label': 'Ss floating button',
          'android:permission': 'android.permission.BIND_ACCESSIBILITY_SERVICE',
        },
        'intent-filter': [
          {
            action: [{ $: { 'android:name': 'android.accessibilityservice.AccessibilityService' } }],
          },
        ],
        'meta-data': [
          {
            $: {
              'android:name': 'android.accessibilityservice',
              'android:resource': '@xml/bubble_service_config',
            },
          },
        ],
      });
    }
    return cfg;
  });

  return config;
};
