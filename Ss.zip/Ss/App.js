import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  Image,
  Linking,
  PanResponder,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Svg, { Path } from 'react-native-svg';
import { captureRef } from 'react-native-view-shot';
import * as ImageManipulator from 'expo-image-manipulator';
import * as MediaLibrary from 'expo-media-library';

const C = {
  bg: '#101418',
  panel: '#1A2026',
  line: '#2A333B',
  text: '#E8EEF2',
  dim: '#8A98A3',
  accent: '#19C39B',
};
const COLORS = ['#FF3B30', '#FFD60A', '#19C39B', '#0A84FF', '#FFFFFF', '#000000'];
const HANDLE = 40;
const MIN_CROP = 48;

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const toPath = (pts) => pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');

function Btn({ label, onPress, active, primary, disabled }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={[s.btn, active && s.btnActive, primary && s.btnPrimary, disabled && { opacity: 0.4 }]}
    >
      <Text style={[s.btnText, primary && { color: '#04130F' }]}>{label}</Text>
    </Pressable>
  );
}

function Editor({ initialUri, onClose }) {
  const [uri, setUri] = useState(initialUri);
  const [size, setSize] = useState(null);
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [mode, setMode] = useState('view');
  const [color, setColor] = useState(COLORS[0]);
  const [strokes, setStrokes] = useState([]);
  const [live, setLive] = useState('');
  const [crop, setCrop] = useState(null);
  const [busy, setBusy] = useState(false);

  const shotRef = useRef(null);
  const pts = useRef([]);
  const drag = useRef(null);

  useEffect(() => {
    Image.getSize(
      uri,
      (w, h) => setSize({ w, h }),
      () => Alert.alert('Could not open the screenshot')
    );
  }, [uri]);

  let disp = null;
  if (size && box.w && box.h) {
    const k = Math.min(box.w / size.w, box.h / size.h);
    disp = { w: size.w * k, h: size.h * k };
  }

  const latest = useRef({});
  latest.current = { mode, color, crop, disp };

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => latest.current.mode !== 'view',
      onPanResponderGrant: (e) => {
        const { mode: m, crop: r } = latest.current;
        const x = e.nativeEvent.locationX;
        const y = e.nativeEvent.locationY;
        if (m === 'draw') {
          pts.current = [[x, y]];
          setLive(toPath(pts.current));
        } else if (m === 'crop' && r) {
          const near = (cx, cy) => Math.abs(x - cx) < HANDLE && Math.abs(y - cy) < HANDLE;
          let handle = null;
          if (near(r.x, r.y)) handle = 'tl';
          else if (near(r.x + r.w, r.y)) handle = 'tr';
          else if (near(r.x, r.y + r.h)) handle = 'bl';
          else if (near(r.x + r.w, r.y + r.h)) handle = 'br';
          else if (x > r.x && x < r.x + r.w && y > r.y && y < r.y + r.h) handle = 'move';
          drag.current = handle ? { handle, rect: { ...r } } : null;
        }
      },
      onPanResponderMove: (e, g) => {
        const { mode: m, disp: d } = latest.current;
        if (m === 'draw') {
          pts.current.push([e.nativeEvent.locationX, e.nativeEvent.locationY]);
          setLive(toPath(pts.current));
        } else if (m === 'crop' && drag.current && d) {
          const { handle, rect } = drag.current;
          let l = rect.x;
          let t = rect.y;
          let r = rect.x + rect.w;
          let b = rect.y + rect.h;
          if (handle === 'move') {
            const dx = clamp(g.dx, -l, d.w - r);
            const dy = clamp(g.dy, -t, d.h - b);
            l += dx; r += dx; t += dy; b += dy;
          } else {
            if (handle.includes('l')) l = clamp(l + g.dx, 0, r - MIN_CROP);
            if (handle.includes('r')) r = clamp(r + g.dx, l + MIN_CROP, d.w);
            if (handle.includes('t')) t = clamp(t + g.dy, 0, b - MIN_CROP);
            if (handle.includes('b')) b = clamp(b + g.dy, t + MIN_CROP, d.h);
          }
          setCrop({ x: l, y: t, w: r - l, h: b - t });
        }
      },
      onPanResponderRelease: () => {
        if (latest.current.mode === 'draw' && pts.current.length) {
          const p = pts.current.length === 1 ? [pts.current[0], [pts.current[0][0] + 0.1, pts.current[0][1]]] : pts.current;
          const stroke = { color: latest.current.color, d: toPath(p) };
          setStrokes((prev) => [...prev, stroke]);
          pts.current = [];
          setLive('');
        }
        drag.current = null;
      },
    })
  ).current;

  const flatten = () =>
    captureRef(shotRef, { format: 'png', quality: 1, result: 'tmpfile', width: size.w, height: size.h });

  const startCrop = () => {
    if (!disp) return;
    setCrop({ x: disp.w * 0.08, y: disp.h * 0.08, w: disp.w * 0.84, h: disp.h * 0.84 });
    setMode('crop');
  };

  const applyCrop = async () => {
    setBusy(true);
    try {
      const flat = await flatten();
      const k = size.w / disp.w;
      const originX = Math.round(crop.x * k);
      const originY = Math.round(crop.y * k);
      const res = await ImageManipulator.manipulateAsync(
        flat,
        [
          {
            crop: {
              originX,
              originY,
              width: Math.min(Math.round(crop.w * k), size.w - originX),
              height: Math.min(Math.round(crop.h * k), size.h - originY),
            },
          },
        ],
        { format: ImageManipulator.SaveFormat.PNG }
      );
      setStrokes([]);
      setCrop(null);
      setMode('view');
      setUri(res.uri);
    } catch (err) {
      Alert.alert('Crop failed', String(err?.message || err));
    }
    setBusy(false);
  };

  const save = async () => {
    setBusy(true);
    try {
      const perm = await MediaLibrary.requestPermissionsAsync(true);
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Allow photo access so Ss can save the screenshot.');
      } else {
        const flat = await flatten();
        await MediaLibrary.saveToLibraryAsync(flat);
        Alert.alert('Saved', 'Screenshot saved to your gallery.');
      }
    } catch (err) {
      Alert.alert('Save failed', String(err?.message || err));
    }
    setBusy(false);
  };

  const fill = StyleSheet.absoluteFill;

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <View style={s.stage} onLayout={(e) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}>
        {disp && (
          <View style={{ width: disp.w, height: disp.h }} {...pan.panHandlers}>
            <View ref={shotRef} collapsable={false} pointerEvents="none" style={fill}>
              <Image source={{ uri }} style={fill} resizeMode="stretch" />
              <Svg width={disp.w} height={disp.h} style={fill}>
                {strokes.map((st, i) => (
                  <Path key={i} d={st.d} stroke={st.color} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" fill="none" />
                ))}
                {!!live && <Path d={live} stroke={color} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" fill="none" />}
              </Svg>
            </View>
            {mode === 'crop' && crop && (
              <View pointerEvents="none" style={fill}>
                <View style={[s.shade, { left: 0, top: 0, right: 0, height: crop.y }]} />
                <View style={[s.shade, { left: 0, top: crop.y + crop.h, right: 0, bottom: 0 }]} />
                <View style={[s.shade, { left: 0, top: crop.y, width: crop.x, height: crop.h }]} />
                <View style={[s.shade, { left: crop.x + crop.w, top: crop.y, right: 0, height: crop.h }]} />
                <View style={[s.cropBox, { left: crop.x, top: crop.y, width: crop.w, height: crop.h }]} />
                {[
                  [crop.x, crop.y],
                  [crop.x + crop.w, crop.y],
                  [crop.x, crop.y + crop.h],
                  [crop.x + crop.w, crop.y + crop.h],
                ].map(([cx, cy], i) => (
                  <View key={i} style={[s.knob, { left: cx - 9, top: cy - 9 }]} />
                ))}
              </View>
            )}
          </View>
        )}
        {(!disp || busy) && (
          <View style={[fill, s.center, busy && { backgroundColor: '#000A' }]}>
            <ActivityIndicator color={C.accent} size="large" />
          </View>
        )}
      </View>

      <View style={s.bar}>
        {mode === 'view' && (
          <>
            <Btn label="Close" onPress={onClose} />
            <Btn label="Draw" onPress={() => setMode('draw')} />
            <Btn label="Crop" onPress={startCrop} />
            <Btn label="Save" primary onPress={save} disabled={busy} />
          </>
        )}
        {mode === 'draw' && (
          <>
            <View style={s.swatches}>
              {COLORS.map((c) => (
                <Pressable key={c} onPress={() => setColor(c)} style={[s.swatch, { backgroundColor: c }, color === c && s.swatchOn]} />
              ))}
            </View>
            <Btn label="Undo" onPress={() => setStrokes((p) => p.slice(0, -1))} disabled={!strokes.length} />
            <Btn label="Done" primary onPress={() => setMode('view')} />
          </>
        )}
        {mode === 'crop' && (
          <>
            <Btn label="Cancel" onPress={() => { setCrop(null); setMode('view'); }} />
            <Btn label="Apply crop" primary onPress={applyCrop} disabled={busy} />
          </>
        )}
      </View>
    </View>
  );
}

function Setup() {
  return (
    <ScrollView style={s.root} contentContainerStyle={{ padding: 24, paddingTop: 72 }}>
      <StatusBar style="light" />
      <Text style={s.h1}>Ss</Text>
      <Text style={s.lead}>A small floating button that captures any screen. Tap it, then draw, crop and save.</Text>

      <Text style={s.h2}>Turn it on</Text>
      <Text style={s.p}>1. Open Accessibility settings and choose Installed apps, then Ss floating button.</Text>
      <Text style={s.p}>2. Switch it on. The green button appears on screen.</Text>
      <Text style={s.p}>
        If the switch is greyed out, open App info for Ss, tap the three-dot menu and choose Allow restricted settings. Then try again.
      </Text>
      <View style={s.row}>
        <Btn label="Accessibility settings" primary onPress={() => Linking.sendIntent('android.settings.ACCESSIBILITY_SETTINGS')} />
        <Btn label="App info" onPress={() => Linking.openSettings()} />
      </View>

      <Text style={s.h2}>Using the button</Text>
      <Text style={s.p}>Tap to capture. Drag to move it; it snaps to the nearest edge. Hold for a moment to change its size (small, medium, large).</Text>
      <Text style={s.p}>Needs Android 11 or newer.</Text>
    </ScrollView>
  );
}

export default function App() {
  const [shot, setShot] = useState(null);

  useEffect(() => {
    const handle = (url) => {
      if (!url) return;
      const m = url.match(/[?&]path=([^&]+)/);
      if (m) setShot('file://' + decodeURIComponent(m[1]));
    };
    Linking.getInitialURL().then(handle);
    const sub = Linking.addEventListener('url', (e) => handle(e.url));
    return () => sub.remove();
  }, []);

  if (shot) {
    return (
      <Editor
        key={shot}
        initialUri={shot}
        onClose={() => {
          setShot(null);
          BackHandler.exitApp();
        }}
      />
    );
  }
  return <Setup />;
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  stage: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 36 },
  center: { alignItems: 'center', justifyContent: 'center' },
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    padding: 12,
    paddingBottom: 24,
    backgroundColor: C.panel,
    borderTopWidth: 1,
    borderTopColor: C.line,
  },
  btn: { paddingHorizontal: 16, paddingVertical: 11, borderRadius: 10, backgroundColor: C.line },
  btnActive: { backgroundColor: '#35424C' },
  btnPrimary: { backgroundColor: C.accent },
  btnText: { color: C.text, fontWeight: '600', fontSize: 15 },
  swatches: { flexDirection: 'row', gap: 8, flex: 1 },
  swatch: { width: 26, height: 26, borderRadius: 13, borderWidth: 1, borderColor: C.line },
  swatchOn: { borderWidth: 3, borderColor: C.accent },
  shade: { position: 'absolute', backgroundColor: '#000A' },
  cropBox: { position: 'absolute', borderWidth: 2, borderColor: C.accent },
  knob: { position: 'absolute', width: 18, height: 18, borderRadius: 9, backgroundColor: C.accent },
  h1: { color: C.text, fontSize: 40, fontWeight: '800' },
  lead: { color: C.dim, fontSize: 16, lineHeight: 23, marginTop: 8 },
  h2: { color: C.text, fontSize: 20, fontWeight: '700', marginTop: 32, marginBottom: 8 },
  p: { color: C.dim, fontSize: 15, lineHeight: 22, marginBottom: 8 },
  row: { flexDirection: 'row', gap: 10, marginTop: 12, flexWrap: 'wrap' },
});
